package com.eshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringrestAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
